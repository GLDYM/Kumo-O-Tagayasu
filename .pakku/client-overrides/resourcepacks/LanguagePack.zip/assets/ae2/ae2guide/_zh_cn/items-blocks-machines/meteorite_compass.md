---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 陨石罗盘
  icon: meteorite_compass
  position: 410
categories:
- tools
item_ids:
- ae2:meteorite_compass
---

# 陨石罗盘

<ItemImage id="meteorite_compass" scale="4" />

陨石罗盘会指向最近的<ItemLink id="mysterious_cube" />，也即指向最近的[陨石](../ae2-mechanics/meteorites.md)。应当首先制作这种AE2物品。

## 配方

<RecipeFor id="meteorite_compass" />
