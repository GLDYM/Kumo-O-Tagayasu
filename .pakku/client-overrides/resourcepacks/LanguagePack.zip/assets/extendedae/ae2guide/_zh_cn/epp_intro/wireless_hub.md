---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME无线集线器
    icon: extendedae:wireless_hub
categories:
- extended devices
item_ids:
- extendedae:wireless_hub
---

# ME无线集线器

<Row gap="20">
<BlockImage id="extendedae:wireless_hub" scale="6"></BlockImage>
</Row>

ME无线集线器的功能和<ItemLink id="extendedae:wireless_connect" />完全一致，但它最多可同时连接8个集线器/连接器。

## 连接配置

ME无线集线器内有8个端口。使用<ItemLink id="extendedae:wireless_tool" />连接时会自动搜寻可用的端口进行连接。

不过，如果所有端口都被占用，则应手动点击“X”按钮断开已有连接以供新建。
