---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 并发处理器
    icon: extendedae:concurrent_processor
categories:
- extended foundation
item_ids:
- extendedae:concurrent_processor
- extendedae:concurrent_processor_press
- extendedae:concurrent_processor_print
---

# 并发处理器

<Row>
<ItemImage id="extendedae:concurrent_processor" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_press" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_print" scale="4"></ItemImage>
</Row>

并发处理器通常用于制造多线程机器，可让它们同时处理多个任务。
