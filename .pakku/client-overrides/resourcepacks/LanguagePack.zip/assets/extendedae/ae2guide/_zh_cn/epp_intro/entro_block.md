---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 恩特罗块
    icon: extendedae:entro_block
categories:
- entro system
item_ids:
- extendedae:entro_block
---

# 恩特罗块

<Row>
<BlockImage id="extendedae:entro_block" scale="8"></BlockImage>
</Row>

用于存储<ItemLink id="extendedae:entro_crystal" />的方块。
