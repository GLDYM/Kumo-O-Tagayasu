---
navigation:
  parent: appflux/appflux-index.md
  title: 绿宝石粉
  icon: appflux:emerald_dust
categories:
- flux materials
item_ids:
- appflux:emerald_dust
---

# 绿宝石粉

<Row>
<ItemImage id="appflux:emerald_dust" scale="4"></ItemImage>
</Row>

磨成粉的绿宝石。
